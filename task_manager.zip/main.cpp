#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {
    vector<string> tasks;
    int choice;

    while (true) {
        cout << "\nWelcome to your daily task manager! Choose an option:\n";
        cout << "1 = Add a task\n";
        cout << "2 = View your tasks\n";
        cout << "3 = Mark a task as complete\n";
        cout << "4 = Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        if (choice == 1) {
            int n;
            cout << "How many tasks do you want to add? ";
            cin >> n;
            cin.ignore(); // To discard newline after number input

            cout << "Enter " << n << " task(s):\n";
            for (int i = 0; i < n; i++) {
                string task;
                getline(cin, task);
                tasks.push_back(task);
            }
        }
        else if (choice == 2) {
            if (tasks.empty()) {
                cout << "No tasks added yet.\n";
            } else {
                cout << "Your tasks:\n";
                for (size_t i = 0; i < tasks.size(); i++) {
                    cout << i + 1 << ". " << tasks[i] << endl;
                }
            }
        }
        else if (choice == 3) {
            if (tasks.empty()) {
                cout << "No tasks to mark as complete.\n";
            } else {
                cout << "Enter the task number to mark as complete: ";
                int index;
                cin >> index;
                if (index >= 1 && index <= tasks.size()) {
                    tasks.erase(tasks.begin() + index - 1);
                    cout << "Task marked as complete and removed.\n";
                } else {
                    cout << "Invalid task number.\n";
                }
            }
        }
        else if (choice == 4) {
            cout << "Goodbye!\n";
            break;
        }
        else {
            cout << "Invalid option. Try again.\n";
        }
    }

    return 0;
}
